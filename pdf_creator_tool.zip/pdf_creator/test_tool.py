import sys
import os

# إضافة المسار
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pdf_creator.core.pdf_engine import PDFEngine
from pdf_creator.utils.table_generator import TableGenerator

def test_creation():
    print("بدء اختبار إنشاء ملف PDF...")
    engine = PDFEngine("test_output.pdf")
    
    # اختبار النص العربي
    engine.add_text("عنوان تجريبي بالعربية", style_name="Title")
    engine.add_text("هذا نص تجريبي للتأكد من أن الأداة تعمل بشكل صحيح وتدعم اللغة العربية بطلاقة.")
    
    # اختبار الجداول
    table_data = [
        ["الاسم", "العمر", "المهنة"],
        ["أحمد", "25", "مهندس"],
        ["سارة", "30", "طبيبة"]
    ]
    engine.add_table(table_data)
    
    engine.save()
    print("تم إنشاء ملف الاختبار بنجاح: test_output.pdf")

if __name__ == "__main__":
    test_creation()
