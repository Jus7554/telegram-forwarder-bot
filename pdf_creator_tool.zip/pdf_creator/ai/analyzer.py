from transformers import pipeline

class DocumentAnalyzer:
    def __init__(self):
        # تحميل النماذج عند الحاجة لتوفير الذاكرة
        self.summarizer = None
        self.sentiment_analyzer = None

    def get_summary(self, text, max_length=130, min_length=30):
        if not self.summarizer:
            self.summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
        
        summary = self.summarizer(text, max_length=max_length, min_length=min_length, do_sample=False)
        return summary[0]['summary_text']

    def analyze_sentiment(self, text):
        if not self.sentiment_analyzer:
            self.sentiment_analyzer = pipeline("sentiment-analysis")
        
        result = self.sentiment_analyzer(text)
        return result[0]

    def extract_keywords(self, text):
        # منطق بسيط لاستخراج الكلمات المفتاحية
        words = text.split()
        # تصفية الكلمات الشائعة (يمكن تحسينها)
        keywords = [word for word in words if len(word) > 4]
        return list(set(keywords))[:10]
