from reportlab.lib import colors

class ColorManager:
    THEMES = {
        "academic": {
            "primary": colors.navy,
            "secondary": colors.grey,
            "accent": colors.darkred,
            "background": colors.whitesmoke
        },
        "creative": {
            "primary": colors.purple,
            "secondary": colors.orange,
            "accent": colors.deeppink,
            "background": colors.lightyellow
        },
        "official": {
            "primary": colors.black,
            "secondary": colors.darkgrey,
            "accent": colors.blue,
            "background": colors.white
        }
    }

    @staticmethod
    def get_theme_colors(theme_name="official"):
        return ColorManager.THEMES.get(theme_name, ColorManager.THEMES["official"])

    @staticmethod
    def suggest_theme_by_content(text):
        # منطق بسيط لاقتراح الثيم بناءً على الكلمات المفتاحية
        academic_keywords = ["بحث", "دراسة", "جامعة", "نتائج", "تحليل"]
        creative_keywords = ["فن", "تصميم", "قصة", "إبداع", "ألوان"]
        
        text_lower = text.lower()
        if any(kw in text_lower for kw in academic_keywords):
            return "academic"
        elif any(kw in text_lower for kw in creative_keywords):
            return "creative"
        return "official"
