import pandas as pd
import io
import re

class TableGenerator:
    @staticmethod
    def detect_and_convert(text):
        """
        يكتشف البيانات الجدولية في النص ويحولها إلى قائمة من القوائم.
        يدعم تنسيقات CSV، الجداول المفصولة بمسافات، أو الجداول المنظمة.
        """
        # محاولة اكتشاف تنسيق CSV بسيط
        lines = text.strip().split('\n')
        if len(lines) > 1:
            # إذا كانت الأسطر تحتوي على فواصل (فاصلة، علامة جدولة، أو |)
            delimiters = [',', '\t', '\|']
            for sep in delimiters:
                if all(re.search(sep, line) for line in lines):
                    try:
                        df = pd.read_csv(io.StringIO(text), sep=sep.replace('\\', ''))
                        return [df.columns.tolist()] + df.values.tolist()
                    except:
                        continue
        
        # إذا لم ينجح، نفترض أنه نص عادي ونحاول تقسيمه بذكاء
        data = []
        for line in lines:
            parts = re.split(r'\s{2,}', line.strip()) # تقسيم عند وجود مسافتين أو أكثر
            if len(parts) > 1:
                data.append(parts)
        
        return data if len(data) > 1 else None
