import argparse
import sys

class PDFCLI:
    def __init__(self):
        self.parser = argparse.ArgumentParser(description="أداة إنشاء ملفات PDF الذكية")
        self.setup_args()

    def setup_args(self):
        self.parser.add_argument("--input", "-i", help="ملف النص المدخل")
        self.parser.add_argument("--output", "-o", default="output.pdf", help="اسم ملف PDF الناتج")
        self.parser.add_argument("--theme", "-t", default="official", choices=["official", "academic", "creative"], help="ثيم المستند")
        self.parser.add_argument("--interactive", action="store_true", help="بدء الوضع التفاعلي")

    def run(self):
        args = self.parser.parse_args()
        
        if args.interactive:
            self.start_interactive_mode()
        elif args.input:
            self.process_file(args.input, args.output, args.theme)
        else:
            self.parser.print_help()

    def start_interactive_mode(self):
        from pdf_creator.core.pdf_engine import PDFEngine
        from pdf_creator.utils.color_manager import ColorManager
        from pdf_creator.utils.table_generator import TableGenerator
        
        print("\n" + "="*40)
        print("   مرحباً بك في أداة إنشاء ملفات PDF الذكية   ")
        print("="*40 + "\n")
        
        title = input("📝 أدخل عنوان المستند: ")
        content = input("📄 أدخل محتوى المستند (أو مسار ملف نصي): ")
        
        if os.path.exists(content):
            with open(content, 'r', encoding='utf-8') as f:
                content = f.read()
        
        theme = ColorManager.suggest_theme_by_content(content)
        print(f"💡 الثيم المقترح بناءً على المحتوى: {theme}")
        
        output = input("💾 اسم ملف الحفظ (default: output.pdf): ") or "output.pdf"
        
        engine = PDFEngine(output, theme=theme)
        engine.add_text(title, style_name="Title")
        
        # خيار التلخيص بالذكاء الاصطناعي
        if len(content.split()) > 100:
            use_ai = input("🤖 المحتوى طويل، هل تود تلخيصه باستخدام الذكاء الاصطناعي؟ (y/n): ").lower()
            if use_ai == 'y':
                from pdf_creator.ai.analyzer import DocumentAnalyzer
                print("⏳ جاري تلخيص النص...")
                analyzer = DocumentAnalyzer()
                content = analyzer.get_summary(content)
                print("✨ تم التلخيص بنجاح!")

        # محاولة اكتشاف جداول
        table_data = TableGenerator.detect_and_convert(content)
        if table_data:
            print("📊 تم اكتشاف بيانات جدولية، جاري إضافتها كجدول...")
            engine.add_table(table_data)
        else:
            engine.add_text(content)
            
        engine.save()
        print(f"\n✅ تم إنشاء الملف بنجاح: {output}")

    def process_file(self, input_path, output_path, theme):
        print(f"جاري معالجة الملف {input_path} باستخدام ثيم {theme}...")
        # منطق المعالجة
