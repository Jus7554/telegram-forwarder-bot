from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
import os

try:
    import pypdf
except ImportError:
    pypdf = None

class PDFEngine:
    def __init__(self, filename, theme="official"):
        self.filename = filename
        self.doc = SimpleDocTemplate(filename, pagesize=A4)
        self.styles = getSampleStyleSheet()
        self.elements = []
        self.theme = theme
        
        # إعداد الخطوط (سيتم إضافة خطوط حقيقية لاحقاً)
        # pdfmetrics.registerFont(TTFont('ArabicFont', 'path/to/font.ttf'))

    def add_text(self, text, style_name="Normal", is_arabic=True):
        from pdf_creator.utils.arabic_handler import reshape_arabic
        
        processed_text = reshape_arabic(text) if is_arabic else text
        style = self.styles[style_name]
        self.elements.append(Paragraph(processed_text, style))
        self.elements.append(Spacer(1, 12))

    def add_table(self, data, is_arabic=True):
        from pdf_creator.utils.arabic_handler import reshape_arabic
        
        if is_arabic:
            processed_data = [[reshape_arabic(str(cell)) for cell in row] for row in data]
        else:
            processed_data = data
            
        table = Table(processed_data)
        # إضافة تنسيق للجداول بناءً على الثيم
        style = TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ])
        table.setStyle(style)
        self.elements.append(table)
        self.elements.append(Spacer(1, 12))

    def save(self):
        self.doc.build(self.elements)
        return self.filename
